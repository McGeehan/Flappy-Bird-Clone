------------------------------------------------------------------
Sprite Pack #1 - Tap and Fly 1.1.0
------------------------------------------------------------------

	This package contains sprites and sounds for making 2D Tap and Fly games in Unity.

	Feel free for commercial or non-commercial use, credit us would be so graceful. :)

	Features:

		� Pixel-art textures for sprites and UIs.
		� Three graphic themes.
		� Sample layouts and screenshots.
		� Sample sounds.

		� Support all build player platforms.
		
	Compatible:

		� Unity 5.5.1 or higher.

	Product page:
	
		https://www.assetstore.unity3d.com/en/#!/content/21454

	Please direct any bugs/comments/suggestions to geteamdev@gmail.com
		
	Thank you for your support,

	Gold Experience Team
	E-mail: geteamdev@gmail.com
	Website: https://www.ge-team.com

------------------------------------------------------------------
Release notes
------------------------------------------------------------------

	Version 1.1.0

		� Unity 5.5.1 or higher compatible.

	Version 1.0.8

		� Unity 5.4.0 or higher compatible.

	Version 1.0.6

		� Unity 4.7.1 or higher compatible.
		� Unity 5.3.4 or higher compatible.

	Version 1.0.5
	
		� Fixed GUID conflict with other packages.
		� Unity 4.6.9 or higher compatible.
		� Unity 5.3.2 or higher compatible.

	Version 1.0

		Initial version.
